from flet import *
from custom_checkbox import CustomCheckBox

def main(page: Page):
    BG = '#041955'
    FWG = '#97b4ff'
    FG = '#3450a1'
    VIO = '#875ef2'


# Блок_1 | Виджеты, к которым необходимо обращаться.    
    TaskName = TextField(
        text_size=22,
        border_radius=25,
        bgcolor=BG,
        border_color=BG,
        color='white',
        label='Задание',
    )

    TaskDesc = TextField(
        text_size=22,
        border_radius=25,
        bgcolor=BG,
        color='white',
        label='Описание задания'
    )
    
    CategoryDropDown = Dropdown(
        width=400,
        height=50,
        color=colors.WHITE,
        bgcolor=BG,
        focused_color=colors.BLACK,
        text_size=12,
        border_radius=25,
        filled=True,
        label='Категория',
        hint_text='Выберите категорию задания',
        options=[
            dropdown.Option("Дом"),
            dropdown.Option("Семья"),
            dropdown.Option("Работа")                             
        ]    
    )

#Блок_1(Конец)

    circle = Stack(
        controls=[
            Container(
                width=100,
                height=100,
                border_radius=50,
                bgcolor=colors.WHITE
            ),
            Container(
                gradient=SweepGradient(
                    center=alignment.center,
                    start_angle=0.0,
                    end_angle=3,
                    stops=[0.5, 0.5],
                    colors=['#00000000', VIO]
                ),
                width=100,
                height=100,
                border_radius=50,
                content=Row(
                    alignment='center',
                    controls=[
                        Container(
                            padding=padding.all(5),
                            bgcolor=BG,
                            width=90,height=90,
                            border_radius=50,
                            content=
                            Container(bgcolor=FG,
                                height=80,width=80,
                                border_radius=40,
                                content=CircleAvatar(opacity=0.8,
                                foreground_image_url="https://animevania.com/wp-content/uploads/2023/04/Ai-Hoshino-1-1024x576.jpg"#place something here
                                )
                            )
                        )
                    ]
                )
            )
        ]
    )

    tasks = Column(
        height=400,
        scroll='auto',
    )

    def add_task(hm):
        tasks.controls.append(
            Container(height=70,
            width=400,
            bgcolor=BG,
            border_radius=25,
            padding=padding.only(left=20,top=25),
            content=CustomCheckBox(color=VIO,
            label=TaskName.value,
            label_color=colors.WHITE)
            )
        )
        page.go('/') # Осталось доделать описание задания и категории.

    def shrink(e):
        page_2.controls[0].width=120
        page_2.controls[0].scale = transform.Scale(0.8, alignment=alignment.center_right)
        page_2.controls[0].border_radius=border_radius.only(
            top_left=25,
            top_right=0,
            bottom_left=35,
            bottom_right=0
        )
        page.update()

    def restore(e):
        page_2.controls[0].width = 400
        page_2.controls[0].border_radius = 35
        page_2.controls[0].scale = transform.Scale(1, alignment=alignment.center_right)
        page_2.update()
    
    
    create_task_page = Container(
        width=400,
        height=850,
        bgcolor=FG,
        border_radius=35,
        content=Column(
            controls=[
                Container(    
                        Stack(
                            controls=[
                                Container(
                                    width=400,
                                    height=40,
                                    alignment=alignment.center,
                                    content=Text(value='New task', color='white', size=20)
                                    ),
                                Container(
                                    on_click=lambda _: page.go('/'),
                                    height=40,
                                    width=40,
                                    content=Icon(name=icons.CLOSE_OUTLINED, color='white')
                                )
                            ]
                        ),
                        width=400,
                        height=40
                ),
                Container(
                    height=50
                ),
                Container(
                    width=400,
                    height=50,
                    padding=padding.only(left=20, right=20),
                    content=TaskName
                ),
                Container(height=30),
                Container(
                    width=400,
                    height=50,
                    padding=padding.only(left=20, right=20),
                    content=TaskDesc  
                ),
                Container(height=30),
                Container(
                    width=400,
                    height=50,
                    padding=padding.only(left=20, right=20),
                    content=
                        Container(
                            width=400,
                            height=50,
                            border_radius=25,
                            content=CategoryDropDown
                        )
                        
                ),
                Container(
                    width=400,
                    padding=padding.only(top=30),
                    alignment=alignment.center,
                    content=
                    FloatingActionButton(
                        shape=RoundedRectangleBorder(radius=5),
                        bgcolor=VIO,
                        width=120,
                        mini=True,
                        on_click= add_task,
                        content=
                            Row(
                                alignment='center',
                                spacing=5,
                                controls=[
                                    Icon(icons.ADD),
                                    Text('Добавить'),
                                ]
                            )
                    )
                )
            ]
        )
    )
        
    

    for i in range(10):
        tasks.controls.append(
            Container(height=70,
            width=400,
            bgcolor=BG,
            border_radius=25,
            padding=padding.only(left=20,top=25),
            content=CustomCheckBox(color=VIO,
            label='Do something',
            label_color=colors.WHITE)
            )
        ) # thats how to add tasks, I will add create task page later

    categories_card = Row(
        scroll='auto'
    )
    categories = ['Дом', 'Семья', 'Работа']
    for i, category in enumerate(categories):
        categories_card.controls.append(
            Container(
                bgcolor=BG,
                height=110,
                width=170,
                border_radius=20,
                padding=15,
                content=Column(
                    controls=[
                        Text(value='N Заданий(я)', color='white'),
                        Text(value=category, color='white'),
                        Container(
                            width=160,
                            height=5,
                            bgcolor='white12',
                            border_radius=20,
                            padding=padding.only(right=i*30),
                            content=Container(
                                bgcolor=VIO
                            )
                        )
                    ]
                )
            )
        )

    first_page_contents = Container(
        content=Column(
            controls=[
                Row(alignment='spaceBetween',
                    controls=[
                        Container(
                            on_click=lambda e: shrink(e),
                            content=Icon(icons.MENU, color=colors.WHITE)
                        ),
                        Row(
                            controls=[
                                Icon(icons.SEARCH, color=colors.WHITE),
                                Icon(icons.NOTIFICATIONS_OUTLINED, color=colors.WHITE)
                            ]
                        ),
                    ]
                ),
                Container(height=20),
                Text(
                    value='Привет, пользователь!',
                    color=colors.WHITE
                ),
                Text(
                    value='Категории',
                    color=colors.WHITE
                ),
                Container(
                    padding=padding.only(top=10,bottom=20),
                    content=categories_card
                ),
                Container(height=20),
                Text(value='Задания на сегодня', color=colors.WHITE),
                Stack(
                    controls=[
                        tasks,
                        FloatingActionButton(
                            bottom = 2,
                            right=20,
                            icon = icons.ADD,
                            on_click = lambda _: page.go('/create_task')
                        )
                    ]
                )
            ]
        )
    )

    page_1 = Container(
        width=400,
        height=850,
        bgcolor=BG,
        border_radius=35,
        padding=padding.only(left=50,top=60,right=200),

        content=Column(
        controls=[
        Row(alignment='end',
        controls=[
            Container(border_radius=25,
            padding=padding.only(
            top=13,left=13,),
            height=50,
            width=50,
            border=border.all(color='white',width=1),
            on_click=lambda e: restore(e),
            content=Icon(icons.ARROW_BACK_IOS_NEW_OUTLINED, color='white60')
            )
        ]
        ),
            Container(height=20),
            circle,
            Text('User',size=32,weight='bold', color=colors.WHITE),
            Container(height=25),
            Row(controls=[
            Icon(icons.FAVORITE_BORDER_SHARP,color='white60'),
            Text('Favourites',size=15,weight=FontWeight.W_300,color='white',font_family='poppins')
            ]),
            Container(height=5),
            Row(controls=[
            Icon(icons.CARD_TRAVEL,color='white60'),
            Text('Categories',size=15,weight=FontWeight.W_300,color='white',font_family='poppins')
            ]),
            Container(height=5),
            Row(controls=[
            Icon(icons.CALCULATE_OUTLINED,color='white60'),
            Text('Analytics',size=15,weight=FontWeight.W_300,color='white',font_family='poppins')
            ]),

            Image(src=f"/assets/images/1.png",
            width=200,
            height=100,
        ),
        Image(src='/images/1.png'),
        Text('Good',color=FG,font_family='poppins',),
        Text('Consistency',size=22, color='white')
        
        ]
        )
    )
    
    page_2 = Row(
        alignment='end',
        controls=[
            Container(
                width=400,
                height=850,
                bgcolor=FG,
                border_radius=35,
                animate=animation.Animation(600, AnimationCurve.DECELERATE),
                animate_scale=animation.Animation(400, curve='decelerate'), # variable curve works same as string up
                padding=padding.only(top=50,left=20,right=20,bottom=5),
                content=Column(
                    controls=[
                        first_page_contents
                    ]
                )
            )
        ]
    )
    
    container = Container(
        width=400,
        height=850,
        bgcolor=BG,
        border_radius=35,
        content=Stack(
            controls=[

                page_1,
                page_2

            ]
        )

    )
    page.add(container)

    pages = {

        '/':View(
            "/",
            [
                container
            ]
        ),
        '/create_task': View(
            '/create_task',
            [
                create_task_page
            ]

        )


    }


    def route_change(route):
        page.views.clear()
        page.views.append(
            pages[page.route]
        )

    page.on_route_change= route_change
    page.go(page.route)

app(target=main, assets_dir='assets')